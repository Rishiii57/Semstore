% Band edges, Fermi level, and carrier concentrations vs Temperature
% Correct behavior at low, extrinsic, and high T
clc; clear; close all;

% Constants
kB_eV = 8.617333262e-5; 
kB_J  = 1.380649e-23;   
h     = 6.62607015e-34; 
m0    = 9.10938356e-31;

% Semiconductor parameters (Si)
Eg0   = 1.17; alpha = 4.73e-4; beta = 636;  
m_eff_n = 1.08*m0; m_eff_p = 0.81*m0;

% Donor parameters
Nd = 1e16; Ed = 0.045; g = 2;

% Temperature
T = linspace(1,1000,400);

% Arrays
Ec = zeros(size(T)); Ev = zeros(size(T)); Ei = zeros(size(T));
Ef = zeros(size(T)); Ed_level = zeros(size(T));
n = zeros(size(T)); p = zeros(size(T));

for i = 1:length(T)
    % Bandgap vs T
    Eg = Eg0 - alpha*T(i)^2/(T(i)+beta);
    Ec(i) = Eg; Ev(i) = 0; 
    Ei(i) = (Ec(i)+Ev(i))/2 + (3/4)*kB_eV*T(i)*log(m_eff_p/m_eff_n); % intrinsic Fermi level
    
    % DOS
    Nc = 2*((2*pi*m_eff_n*kB_J*T(i))/(h^2))^(3/2)/1e6;
    Nv = 2*((2*pi*m_eff_p*kB_J*T(i))/(h^2))^(3/2)/1e6;
    
    ni(i) = sqrt(Nc*Nv)*exp(-Eg/(2*kB_eV*T(i)));
    
    % Donor level
    Ed_level(i) = Ec(i) - Ed;
    
    % ----- Determine Fermi level -----
    if T(i) < 5  % ~0K
        Ef(i) = (Ec(i)+Ed_level(i))/2;
    elseif ni > 10*Nd  % Intrinsic regime
        Ef(i) = Ei(i);
    else
        % Charge neutrality function
        f = @(Ef0) Nc*exp(-(Ec(i)-Ef0)/(kB_eV*T(i))) - Nv*exp(-(Ef0-Ev(i))/(kB_eV*T(i))) ...
                   - Nd/(1+g*exp((Ef0-Ed_level(i))/(kB_eV*T(i))));
        % Initial guess
        Ef0_guess = Ec(i) - kB_eV*T(i)*log(Nc/Nd);
        Ef(i) = fzero(f, Ef0_guess);
    end
    
    % Electron and hole concentrations
    n(i) = Nc*exp(-(Ec(i)-Ef(i))/(kB_eV*T(i)));
    p(i) = Nv*exp(-(Ef(i)-Ev(i))/(kB_eV*T(i)));
end

% Determine regions
freeze_idx = find(n < 0.1*Nd);
extrinsic_idx = find(n >= 0.1*Nd & n <= 10*Nd);
intrinsic_idx = find(n > 10*Nd);

% -------- Plot: Band diagram with shaded regions --------
figure; hold on;

ymin = min([Ev Ef Ed_level])-0.1; ymax = max([Ec Ef Ed_level])+0.1;

% Shade regions
if ~isempty(freeze_idx)
    area(T(freeze_idx), ymax*ones(size(freeze_idx)),'FaceColor',[0.9 0.9 1],'EdgeColor','none')
end
if ~isempty(extrinsic_idx)
    area(T(extrinsic_idx), ymax*ones(size(extrinsic_idx)),'FaceColor',[0.9 1 0.9],'EdgeColor','none')
end
if ~isempty(intrinsic_idx)
    area(T(intrinsic_idx), ymax*ones(size(intrinsic_idx)),'FaceColor',[1 0.9 0.9],'EdgeColor','none')
end

plot(T, Ec,'r-','LineWidth',2);
plot(T, Ev,'b-','LineWidth',2);
plot(T, Ei,'k--','LineWidth',1.5);
plot(T, Ef,'m:','LineWidth',2);
plot(T, Ed_level,'g-.','LineWidth',1.5);

xlabel('Temperature (K)'); ylabel('Energy (eV)');
title('Band Diagram vs Temperature (n-type Si with N_D = 10^{16} /cm^3)');
legend('Freeze-out','Extrinsic','Intrinsic','E_c','E_v','E_i','E_f','E_d','Location','best');
grid on; ylim([ymin ymax]);

% -------- Plot: Carrier concentrations --------
figure;
semilogy(T, n,'r-','LineWidth',2); hold on;
semilogy(T, p,'b--','LineWidth',2);
semilogy(T, ni,'k:','LineWidth',2);
xlabel('Temperature (K)');
ylabel('Carrier concentration (cm^{-3})');
title('Carrier Concentrations vs Temperature (n-type Si)');
legend('Electrons (n)','Holes (p)','Intrinsic (n_i)','Location','NorthWest');
ylim([10^0 10^20])


% -------- Plot: Carrier concentrations --------
figure;
plot(T, n,'r-','LineWidth',2); hold on;
plot(T, p,'b--','LineWidth',2);
plot(T, ni,'k:','LineWidth',2);
xlabel('Temperature (K)');
ylabel('Carrier concentration (cm^{-3})');
title('Carrier Concentrations vs Temperature (n-type Si)');
legend('Electrons (n)','Holes (p)','Intrinsic (n_i)','Location','NorthWest');
% ylim([10^0 10^20])

grid on;