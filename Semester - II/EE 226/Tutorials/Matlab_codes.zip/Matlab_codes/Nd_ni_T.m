% Electron concentration vs. Temperature 
% Intrinsic and Extrinsic (n-type) Semiconductors with Freeze-out
%code writing help ChatGPT

clc; clear; close all;
colors = lines(6); 
% Physical constants
kB = 8.617e-5;          % Boltzmann constant (eV/K)
q  = 1.6e-19;           % Electron charge (C)
h  = 6.626e-34;         % Planck's constant (J*s)
m0 = 9.11e-31;          % Electron rest mass (kg)

% Semiconductor parameters (Silicon as example)
Eg  = 1.12;             % Bandgap of Si at 300K (eV)
meff_n = 1.08*m0;       % Effective mass of electrons
meff_p = 0.56*m0;       % Effective mass of holes

% Donor properties
Nd = [1e14 1e16 1e18];              % Donor concentration (cm^-3)
Ed = 0.0045;             % Donor ionization energy (eV) for Si:P
g  = 2;                 % Degeneracy factor

% Temperature range
T = linspace(0, 1000, 300); % Kelvin

% Effective density of states Nc, Nv (cm^-3)
Nc = 2*((2*pi*meff_n*kB*q)./(h^2))^(3/2) .* (T.^(3/2)) / 1e6; 
Nv = 2*((2*pi*meff_p*kB*q)./(h^2))^(3/2) .* (T.^(3/2)) / 1e6;

% Intrinsic carrier concentration ni (cm^-3)
ni = sqrt(Nc.*Nv) .* exp(-Eg./(2*kB*T));

% ---------------- Freeze-out Model ----------------
% Ionized donor fraction (Fermi-Dirac approx)
% Nd+ = Nd / (1 + g*exp((Ef - Ed)/kBT)), 
% simplified using charge neutrality iteration

n_freezeout = zeros(size(T));
figure;

for j = 1:length(Nd)
for i = 1:length(T)
    % Thermal ionization probability of donor
    etaD = exp(-Ed/(kB*T(i))); 
    % Ionized donor concentration
    N_d_plus(i) = Nd(j) * etaD ./ (1 + g*etaD); 
    % Electron concentration considering donors + intrinsic
    n_freezeout(i) = (N_d_plus(i)/2) + sqrt((N_d_plus(i)/2)^2 + ni(i)^2);
end

% --------------------------------------------------

% Plotting
figure(1)
semilogy(T, N_d_plus, 'Color',colors(j,:),'LineWidth', 2);hold on;
semilogy(T, n_freezeout, 'Color',colors(j+1,:), 'LineStyle', '--', 'LineWidth', 1.5);hold on;
figure(2)
semilogy(1000./T, N_d_plus, 'Color',colors(j,:),'LineWidth', 2);hold on;
semilogy(1000./T, n_freezeout, 'Color',colors(j+1,:), 'LineStyle', '--', 'LineWidth', 1.5);hold on;
end
figure(1)
semilogy(T, ni, 'Color',colors(j+1,:), 'LineWidth', 1); 
figure(2)
semilogy(1000./T, ni, 'Color',colors(j+1,:), 'LineWidth', 1); 

figure(1)

xlabel('Temperature (K)', 'FontSize', 12);
ylabel('Electron Concentration (cm^{-3})', 'FontSize', 12);
legend('$N_d = 10^{14} with Ionization$', '$Total electrons with N_d = 10^{14}$' , '$N_d = 10^{16} with Ionization$', '$Total electrons with N_d = 10^{16}$' , '$N_d = 10^{18} with Ionization$', '$Total electrons with N_d = 10^{18}$' ,  '$Intrinsic (n_i)$', 'Interpreter','latex','Location', 'best');
%title('Electron Concentration vs. Temperature (with Freeze-out)', 'FontSize', 14);
grid on;
ylim([10^0 10^20])
figure(2)

xlabel('1000/T', 'FontSize', 12);
ylabel('Electron Concentration (cm^{-3})', 'FontSize', 12);
legend('$N_d = 10^{14} with Ionization$', '$Total electrons with N_d = 10^{14}$' , '$N_d = 10^{16} with Ionization$', '$Total electrons with N_d = 10^{16}$' , '$N_d = 10^{18} with Ionization$', '$Total electrons with N_d = 10^{18}$' ,  '$Intrinsic (n_i)$', 'Interpreter','latex','Location', 'best');
%title('Electron Concentration vs. Temperature (with Freeze-out)', 'FontSize', 14);
grid on;
xlim([0 10])
ylim([10^0 10^20])
