% Intrinsic Carrier Concentration vs Temperature
%code writing help ChatGPT
clear; clc;close all;

% Constants
kB = 8.617333e-5;   % Boltzmann constant [eV/K]
h = 6.626e-34;      % Planck's constant [J*s]
q = 1.602e-19;      % Electron charge [C]
m0 = 9.109e-31;     % Electron rest mass [kg]

% Effective masses for Silicon
me_eff = 1.08*m0;   % Effective electron mass
mh_eff = 0.56*m0;   % Effective hole mass

% Temperature range
T = 0:5:800;   % Kelvin

% Bandgap energy variation with T (Silicon - Varshni's equation)
Eg = 1.17 - (4.73e-4*T.^2)./(T + 636);  % in eV

% Effective density of states Nc and Nv
Nc = 2*((2*pi*me_eff*kB*T*q)/(h^2)).^(3/2);  % [cm^-3]
Nv = 2*((2*pi*mh_eff*kB*T*q)/(h^2)).^(3/2);  % [cm^-3]

% Convert from m^-3 to cm^-3
%Nc = Nc / 1e6;
Nv = Nv / 1e6;

% Intrinsic carrier concentration
ni = sqrt(Nc .* Nv) .* exp(-Eg./(2*kB*T));

% Plot
figure;
%semilogy(T,sqrt(Nc .* Nv),'b','LineWidth',1);
%hold on
%semilogy(T,exp(-Eg./(2*kB*T)),'g','LineWidth',1);
yyaxis left
semilogy(T,ni,'r','LineWidth',2);
ylim([10^-15 10^22])
ylabel('Intrinsic carrier concentration (cm^{-3})');

yyaxis right

plot(T,ni,'b','LineWidth',2);

xlabel('Temperature (K)');
ylabel('Intrinsic carrier concentration (cm^{-3})');
%title('Intrinsic Carrier Concentration vs Temperature (Si)');
%legend('$\sqrt{N_c N_v} \propto T^{3/2}$', '$\exp\left(-\frac{E_g}{2k_BT}\right)$', '$n_i = \sqrt{N_c N_v} \exp\left(-\frac{E_g}{2k_BT}\right)$', ...
%       'Interpreter','latex','Location','best');

grid on;

% Plot
figure;
semilogy(T,sqrt(Nc .* Nv),'b','LineWidth',1);
hold on
semilogy(T,exp(-Eg./(2*kB*T)),'g','LineWidth',1);
% yyaxis left
semilogy(T,ni,'r','LineWidth',2);
ylim([10^-15 10^22])
% ylabel('Intrinsic carrier concentration (cm^{-3})');

% yyaxis right

% plot(T,ni,'b','LineWidth',2);

xlabel('Temperature (K)');
ylabel('Intrinsic carrier concentration (cm^{-3})');
%title('Intrinsic Carrier Concentration vs Temperature (Si)');
legend('$\sqrt{N_c N_v} \propto T^{3/2}$', '$\exp\left(-\frac{E_g}{2k_BT}\right)$', '$n_i = \sqrt{N_c N_v} \exp\left(-\frac{E_g}{2k_BT}\right)$', ...
       'Interpreter','latex','Location','best');

grid on;